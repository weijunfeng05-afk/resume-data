import {ensureLegacyOwnerSettings,getSettingsStatus,saveConfiguration,testConfiguration,removeConfiguration} from '@/lib/ai/settings';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {db,runtime,json,AppError} from '@/lib/db';
import {jobInput,jobOutput,cardSchema} from '@/lib/ai/schema';
import {JOB_PROMPT} from '@/lib/ai/prompts';
import {callAI} from '@/lib/ai/client';
import {checkFile,parseDocument} from '@/lib/documents';
import {processCandidate} from '@/lib/processing';
import {ZodError} from 'zod';
export const dynamic='force-dynamic';
async function handler(req:Request){
 try{
  const user=await getChatGPTUser();if(!user)return json({error:'请先登录工作空间'},401);const owner=user.userId;
  if(req.method!=='GET'){const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'无效的请求来源'},403);}
  const parts=new URL(req.url).pathname.slice(5).split('/');const [kind,id,action]=parts,d=db();
  const ownedJob=async(jobId:string)=>{const j:any=await d.prepare('SELECT * FROM jobs WHERE id=? AND owner=?').bind(jobId,owner).first();if(!j)throw new AppError('岗位不存在',404);return j;};
  await ensureLegacyOwnerSettings(user);
  if(kind==='status'&&req.method==='GET')return json({ai_configured:(await getSettingsStatus(owner)).configured});
  if(kind==='settings'&&id==='ai'){
    if(req.method==='GET'&&!action)return json(await getSettingsStatus(owner));
    if(req.method==='PUT'&&!action)return json(await saveConfiguration(owner,await req.json()));
    if(req.method==='POST'&&action==='test')return json(await testConfiguration(owner,await req.json()));
    if(req.method==='DELETE'&&!action)return json(await removeConfiguration(owner,await req.json()));
  }
  if(kind==='documents'&&req.method==='POST'){const form=await req.formData(),file=form.get('file');if(!(file instanceof File))throw new AppError('请选择文件');checkFile(file);return json({text:await parseDocument(await file.arrayBuffer(),file.name)});}
  if(kind==='jobs'&&!id&&req.method==='GET'){const rows=await d.prepare("SELECT j.*,COUNT(c.id) AS count,SUM(CASE WHEN e.score>=85 AND e.status='completed' THEN 1 ELSE 0 END) AS high,SUM(CASE WHEN c.created>=? THEN 1 ELSE 0 END) AS today FROM jobs j LEFT JOIN candidates c ON c.job_id=j.id LEFT JOIN evaluations e ON e.candidate_id=c.id WHERE j.owner=? GROUP BY j.id ORDER BY j.updated DESC").bind(Date.now()-86400000,owner).all();return json(rows.results.map((r:any)=>({...r,profile:JSON.parse(r.profile)})));}
  if(kind==='jobs'&&!id&&req.method==='POST'){
   const input=jobInput.parse(await req.json()),jobId=crypto.randomUUID(),now=Date.now();
   const output=await callAI('job',jobId,owner,JOB_PROMPT,input,x=>jobOutput.parse(x));
   await d.batch([d.prepare('INSERT INTO jobs (id,owner,name,department,location,level,notes,jd,profile,version,confirmed,created,updated) VALUES (?,?,?,?,?,?,?,?,?,1,0,?,?)').bind(jobId,owner,input.name,input.department,input.location,input.level,input.notes,input.jd,JSON.stringify(output.profile),now,now),d.prepare('INSERT INTO scorecards (id,job_id,version,data,created) VALUES (?,?,1,?,?)').bind(crypto.randomUUID(),jobId,JSON.stringify(output.scorecard),now)]);
   return json({id:jobId},201);
  }
  if(kind==='jobs'&&id){const job=await ownedJob(id);
   if(req.method==='GET'&&!action){const card:any=await d.prepare('SELECT * FROM scorecards WHERE job_id=? AND version=?').bind(id,job.version).first();return json({...job,profile:JSON.parse(job.profile),scorecard:JSON.parse(card.data)});}
   if(action==='scorecard'&&req.method==='PUT'){
    const body:any=await req.json(),card=cardSchema.parse(body.scorecard);if(!Number.isInteger(body.version)||body.version!==job.version)throw new AppError('评分卡已被更新，请刷新后再修改',409);
    const now=Date.now();const results=await d.batch([d.prepare('INSERT INTO scorecards (id,job_id,version,data,created) SELECT ?,id,version+1,?,? FROM jobs WHERE id=? AND owner=? AND version=?').bind(crypto.randomUUID(),JSON.stringify(card),now,id,owner,body.version),d.prepare('UPDATE jobs SET version=version+1,confirmed=1,updated=? WHERE id=? AND owner=? AND version=?').bind(now,id,owner,body.version)]);
    if(!results[0].meta.changes)throw new AppError('评分卡已被更新，请刷新后再修改',409);return json({version:body.version+1});
   }
   if(action==='candidates'&&req.method==='GET'){
    const rows=await d.prepare('SELECT c.id,c.name,c.filename,c.created,e.status,e.score,e.version,e.error,e.result,e.updated FROM candidates c JOIN evaluations e ON e.candidate_id=c.id WHERE c.job_id=? ORDER BY e.score DESC,c.created DESC').bind(id).all();return json(rows.results.map((r:any)=>({...r,result:r.result?JSON.parse(r.result):null})));
   }
   if(action==='upload'&&req.method==='POST'){
    if(!job.confirmed)throw new AppError('请先校准并保存评分卡');
    const form=await req.formData(),file=form.get('file');if(!(file instanceof File))throw new AppError('请选择简历');checkFile(file);
    const candidateId=crypto.randomUUID(),fileKey=owner+'/'+candidateId,now=Date.now();
    const mime=/\.pdf$/i.test(file.name)?'application/pdf':'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    await runtime().BUCKET.put(fileKey,await file.arrayBuffer(),{httpMetadata:{contentType:mime}});
    const scorecard:any=await d.prepare('SELECT id FROM scorecards WHERE job_id=? AND version=?').bind(id,job.version).first();
    try{await d.batch([d.prepare('INSERT INTO candidates (id,job_id,name,filename,file_key,mime,created) VALUES (?,?,?,?,?,?,?)').bind(candidateId,id,file.name.replace(/\.[^.]+$/,''),file.name,fileKey,mime,now),d.prepare("INSERT INTO evaluations (id,candidate_id,scorecard_id,version,status,created,updated) VALUES (?,?,?,?,'waiting',?,?)").bind(crypto.randomUUID(),candidateId,scorecard.id,job.version,now,now),d.prepare('UPDATE jobs SET updated=? WHERE id=?').bind(now,id)]);}catch(e){await runtime().BUCKET.delete(fileKey);throw e;}
    const encoder=new TextEncoder();let cancelled=false;
    return new Response(new ReadableStream({async start(controller){const send=(data:unknown)=>{if(!cancelled){try{controller.enqueue(encoder.encode(JSON.stringify(data)+'\n'))}catch{cancelled=true}}};send({id:candidateId,status:'waiting'});try{await processCandidate(candidateId,owner);send({id:candidateId,status:'finished'});}catch{send({id:candidateId,status:'interrupted'});}finally{if(!cancelled)controller.close();}},cancel(){cancelled=true;}}),{headers:{'Content-Type':'application/x-ndjson','Cache-Control':'no-store'}});
   }
  }
  if(kind==='candidates'&&id){const c:any=await d.prepare('SELECT c.*,e.status,e.score,e.version,e.result,e.error,e.scorecard_id,e.updated FROM candidates c JOIN jobs j ON j.id=c.job_id JOIN evaluations e ON e.candidate_id=c.id WHERE c.id=? AND j.owner=?').bind(id,owner).first();if(!c)throw new AppError('候选人不存在',404);
   if(action==='retry'&&req.method==='POST'){await processCandidate(id,owner);return json({ok:true});}
   if(action==='file'&&req.method==='GET'){const obj=await runtime().BUCKET.get(c.file_key);if(!obj)throw new AppError('文件不存在',404);return new Response(obj.body,{headers:{'Content-Type':c.mime,'Content-Disposition':`${c.mime==='application/pdf'?'inline':'attachment'}; filename*=UTF-8''${encodeURIComponent(c.filename)}`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});}
   if(req.method==='GET'&&!action){const card:any=await d.prepare('SELECT data FROM scorecards WHERE id=?').bind(c.scorecard_id).first();return json({...c,file_key:undefined,result:c.result?JSON.parse(c.result):null,profile:c.profile?JSON.parse(c.profile):null,scorecard:JSON.parse(card.data)});}
  }
  return json({error:'接口不存在'},404);
 }catch(e){if(e instanceof ZodError)return json({error:e.issues.map(x=>x.message).join('；')},400);if(e instanceof AppError)return json({error:e.message},e.status);console.error('API request failed',e instanceof Error?e.name:'unknown');return json({error:'服务暂时不可用，请稍后重试；已保存的数据不会丢失。'},503);}
}
export const GET=handler;export const POST=handler;export const PUT=handler;export const DELETE=handler;
