# 数据库与服务端接口

数据库定义以 db/schema.ts 为准，生产变更仅通过 drizzle/ 迁移。所有对象访问通过岗位owner校验；身份来自平台验证后的用户头。R2原件必须经过受保护接口访问。

- jobs：id、owner、name、department、location、level、notes、jd、profile、version、confirmed、created、updated。
- scorecards：id、job_id外键、version、data(JSON维度/权重/rubric/Must-have/Nice-to-have)、created。job_id+version唯一。
- candidates：id、job_id外键、name、filename、file_key、mime、resume_text、profile、created。
- evaluations：id、candidate_id唯一外键、scorecard_id外键、version、status、score、result、error、lease、updated、created。上传时固定评分卡快照；解析与评分状态可恢复。
- ai_calls：id、owner、subject、task、model、attempt、latency、input_tokens、output_tokens、estimated_cost、json_valid、success、created。价格估算币种USD；缺usage时Token/费用为null。

| 接口 | 作用 |
|---|---|
| GET /api/status | 只返回AI配置是否存在，不返回密钥 |
| GET /api/jobs | 岗位列表及候选人、高优统计 |
| POST /api/jobs | JD分析一次、画像和草稿评分卡原子保存 |
| GET /api/jobs/:id | 画像、原JD、当前评分卡 |
| PUT /api/jobs/:id/scorecard | body {version,scorecard}，乐观锁、新版本、确认 |
| POST /api/documents | multipart file，提取JD文字 |
| POST /api/jobs/:id/upload | multipart file，存档后自动解析评分，NDJSON状态流 |
| GET /api/jobs/:id/candidates | 评分降序的候选人 |
| GET /api/candidates/:id | 原文、候选人事实、历史评分卡、评价 |
| POST /api/candidates/:id/retry | 对未完成任务领取租约并重试；已完成幂等返回 |
| GET /api/candidates/:id/file | 受保护PDF内嵌或DOCX下载 |

错误：400字段或文件校验；401未登录；403请求来源不符；404非本人或不存在；409评分卡版本冲突；502模型请求或结果失败；503配置/存储不可用。

状态：waiting → parsing → scoring → completed；任意阶段异常 → failed。重试使用同一个原件、同一个评分卡。使用数据库条件更新领取4分钟租约，避免同一候选人被多个页面同时处理。

## 排名口径
总分由后端逐项加总，不能相信模型的总分。高优>=85；建议查看70–84；人工判断55–69；低优<55。不同评分卡版本明确标记，不覆盖历史数据。
