import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {build} from 'esbuild';

const database=new DatabaseSync(':memory:');
database.exec(readFileSync('drizzle/0000_sparkling_champions.sql','utf8'));
const binding={prepare(sql){return {sql,args:[],bind(...args){this.args=args;return this},async first(){return database.prepare(this.sql).get(...this.args)||null},async run(){const r=database.prepare(this.sql).run(...this.args);return {meta:{changes:Number(r.changes)}}}}},async batch(statements){database.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.run());database.exec('COMMIT');return results;}catch(e){database.exec('ROLLBACK');throw e;}}};
globalThis.__aiFixtureEnv={DB:binding,DEEPSEEK_API_KEY:'test-only-not-a-real-key'};
await build({entryPoints:['lib/processing.ts'],bundle:true,platform:'node',format:'esm',packages:'external',outfile:'work/test-pipeline.mjs',plugins:[{name:'test-runtime',setup(b){b.onResolve({filter:/^cloudflare:workers$/},()=>({path:'runtime',namespace:'test'}));b.onLoad({filter:/.*/,namespace:'test'},()=>({contents:'export const env=globalThis.__aiFixtureEnv;',loader:'js'}));}}]});
const {processCandidate}=await import('../work/test-pipeline.mjs');
const card={dimensions:[{id:'d1',name:'项目经验',weight:100,rubric:'按主导深度与实际成果评分'}],must_have:['Agent 项目'],nice_to_have:[]};
const text='主导 Agent 工作流设计，完成知识库产品上线，服务 1000 位用户。';
database.prepare('INSERT INTO jobs (id,owner,name,jd,profile,created,updated) VALUES (?,?,?,?,?,?,?)').run('job','owner','测试岗位','PRIVATE_ORIGINAL_JD_SHOULD_NOT_BE_RESENT',JSON.stringify({summary:'Agent产品岗位',responsibilities:[],keywords:[]}),1,1);
database.prepare('INSERT INTO scorecards (id,job_id,version,data,created) VALUES (?,?,?,?,?)').run('card','job',1,JSON.stringify(card),1);
function seed(id){database.prepare('INSERT INTO candidates (id,job_id,name,filename,file_key,mime,resume_text,created) VALUES (?,?,?,?,?,?,?,?)').run(id,'job','待提取','synthetic.pdf','fixture','application/pdf',text,1);database.prepare('INSERT INTO evaluations (id,candidate_id,scorecard_id,version,status,created,updated) VALUES (?,?,?,?,?,?,?)').run('eval-'+id,id,'card',1,'waiting',1,1)}
const output=()=>({candidate_profile:{name:'匿名测试候选人',education:[],experience:[],projects:[],skills:['Agent'],achievements:[]},dimension_scores:[{id:'d1',score:86,evidence:['主导 Agent 工作流设计'],reason:'有主导和上线证据'}],strengths:['具备项目经历'],risks:[],must_have:[{requirement:'Agent 项目',status:'met',evidence:'主导 Agent 工作流设计'}],confidence:.8});
function success(content){return Response.json({choices:[{finish_reason:'stop',message:{content:typeof content==='string'?content:JSON.stringify(content)}}],usage:{prompt_tokens:100,completion_tokens:50,prompt_cache_hit_tokens:20}})}

test('完整评分链路：事实、分项、总分、版本与Token入库；不重传JD；完成状态幂等',async()=>{
 seed('success');let calls=0;
 globalThis.fetch=async(url,options)=>{calls++;assert.equal(url,'https://api.deepseek.com/chat/completions');const body=JSON.parse(options.body);assert.equal(body.model,'deepseek-v4-flash');assert.deepEqual(body.response_format,{type:'json_object'});assert.equal(body.messages.length,2);assert.ok(!options.body.includes('PRIVATE_ORIGINAL_JD_SHOULD_NOT_BE_RESENT'));assert.ok(options.body.includes(text));return success(output())};
 await processCandidate('success','owner');await processCandidate('success','owner');assert.equal(calls,1);
 const row=database.prepare('SELECT * FROM evaluations WHERE candidate_id=?').get('success');assert.equal(row.status,'completed');assert.equal(row.score,86);assert.equal(row.version,1);assert.equal(row.lease,null);
 assert.equal(JSON.parse(database.prepare('SELECT profile FROM candidates WHERE id=?').get('success').profile).name,'匿名测试候选人');
 const metric=database.prepare('SELECT * FROM ai_calls WHERE subject=?').get('success');assert.equal(metric.input_tokens,100);assert.equal(metric.output_tokens,50);assert.equal(metric.success,1);assert.ok(metric.estimated_cost>0);
});
test('首次空JSON自动重试一次，分别记录失败与成功尝试',async()=>{
 seed('retry');let calls=0;globalThis.fetch=async()=>++calls===1?success(''):success(output());await processCandidate('retry','owner');assert.equal(calls,2);assert.equal(database.prepare('SELECT status FROM evaluations WHERE candidate_id=?').get('retry').status,'completed');const metrics=database.prepare('SELECT attempt,json_valid,success FROM ai_calls WHERE subject=? ORDER BY attempt').all('retry');assert.deepEqual(metrics.map(x=>({...x})),[{attempt:1,json_valid:0,success:0},{attempt:2,json_valid:1,success:1}]);
});
test('两次业务校验失败后保留简历、版本和失败状态，不落假分',async()=>{
 seed('invalid');let calls=0;globalThis.fetch=async()=>{calls++;const r=output();r.dimension_scores[0].evidence=['这是简历中不存在的成果'];return success(r)};await processCandidate('invalid','owner');assert.equal(calls,2);const row=database.prepare('SELECT * FROM evaluations WHERE candidate_id=?').get('invalid');assert.equal(row.status,'failed');assert.equal(row.score,null);assert.equal(row.result,null);assert.equal(row.lease,null);assert.ok(row.error);assert.equal(database.prepare('SELECT resume_text FROM candidates WHERE id=?').get('invalid').resume_text,text);
});
test('HTTP限流最多调用两次；非所有者不能触发分析',async()=>{
 seed('rate');let calls=0;globalThis.fetch=async()=>{calls++;return new Response('',{status:429})};await assert.rejects(processCandidate('rate','other'));assert.equal(calls,0);await processCandidate('rate','owner');assert.equal(calls,2);assert.match(database.prepare('SELECT error FROM evaluations WHERE candidate_id=?').get('rate').error,/繁忙/);
});
test('同一候选人并发领取，只产生一次模型调用',async()=>{
 seed('concurrent');let calls=0;globalThis.fetch=async()=>{calls++;await new Promise(r=>setTimeout(r,30));return success(output())};await Promise.all([processCandidate('concurrent','owner'),processCandidate('concurrent','owner')]);assert.equal(calls,1);assert.equal(database.prepare('SELECT status FROM evaluations WHERE candidate_id=?').get('concurrent').status,'completed');
});
