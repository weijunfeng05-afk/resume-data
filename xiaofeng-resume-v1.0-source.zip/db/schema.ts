import {sqliteTable,text,integer,real,index,uniqueIndex} from 'drizzle-orm/sqlite-core';
export const jobs=sqliteTable('jobs',{id:text('id').primaryKey(),owner:text('owner').notNull(),name:text('name').notNull(),department:text('department').notNull().default(''),location:text('location').notNull().default(''),level:text('level').notNull().default(''),notes:text('notes').notNull().default(''),jd:text('jd').notNull(),profile:text('profile').notNull(),version:integer('version').notNull().default(1),confirmed:integer('confirmed').notNull().default(0),created:integer('created').notNull(),updated:integer('updated').notNull()},t=>[index('jobs_owner_updated').on(t.owner,t.updated)]);
export const scorecards=sqliteTable('scorecards',{id:text('id').primaryKey(),jobId:text('job_id').notNull().references(()=>jobs.id),version:integer('version').notNull(),data:text('data').notNull(),created:integer('created').notNull()},t=>[uniqueIndex('scorecards_job_version').on(t.jobId,t.version)]);
export const candidates=sqliteTable('candidates',{id:text('id').primaryKey(),jobId:text('job_id').notNull().references(()=>jobs.id),name:text('name').notNull(),filename:text('filename').notNull(),fileKey:text('file_key').notNull(),mime:text('mime').notNull(),resumeText:text('resume_text'),profile:text('profile'),created:integer('created').notNull()},t=>[index('candidates_job_created').on(t.jobId,t.created)]);
export const evaluations=sqliteTable('evaluations',{id:text('id').primaryKey(),candidateId:text('candidate_id').notNull().references(()=>candidates.id),scorecardId:text('scorecard_id').notNull().references(()=>scorecards.id),version:integer('version').notNull(),status:text('status').notNull(),score:integer('score'),result:text('result'),error:text('error'),lease:text('lease'),updated:integer('updated').notNull(),created:integer('created').notNull()},t=>[uniqueIndex('evaluation_candidate').on(t.candidateId),index('evaluation_status').on(t.status)]);
export const aiCalls=sqliteTable('ai_calls',{id:text('id').primaryKey(),owner:text('owner').notNull(),subject:text('subject').notNull(),task:text('task').notNull(),model:text('model').notNull(),attempt:integer('attempt').notNull(),latency:integer('latency').notNull(),inputTokens:integer('input_tokens'),outputTokens:integer('output_tokens'),estimatedCost:real('estimated_cost'),jsonValid:integer('json_valid').notNull(),success:integer('success').notNull(),created:integer('created').notNull()},t=>[index('calls_owner_created').on(t.owner,t.created)]);

export const apiSettings = sqliteTable('api_settings', {
  owner: text('owner').primaryKey(),
  encryptedKey: text('encrypted_key'),
  keySuffix: text('key_suffix'),
  jobModel: text('job_model').notNull().default('deepseek-v4-pro'),
  resumeModel: text('resume_model').notNull().default('deepseek-v4-flash'),
  version: integer('version').notNull().default(1),
  updated: integer('updated').notNull(),
});
