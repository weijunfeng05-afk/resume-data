import {db,runtime,AppError} from './db';
import {parseDocument} from './documents';
import {callAI} from './ai/client';
import {cardSchema,validateEvaluation} from './ai/schema';
import {resumePrompt} from './ai/prompts';
export async function processCandidate(id:string,owner:string){
 const d=db(),token=crypto.randomUUID(),now=Date.now();
 const row:any=await d.prepare('SELECT c.*, e.id AS evaluation_id,e.status,e.scorecard_id,e.updated AS evaluated_at, j.profile AS job_profile FROM candidates c JOIN jobs j ON j.id=c.job_id JOIN evaluations e ON e.candidate_id=c.id WHERE c.id=? AND j.owner=?').bind(id,owner).first();
 if(!row)throw new AppError('候选人不存在',404);
 if(row.status==='completed')return;
 const claim=await d.prepare("UPDATE evaluations SET lease=?,status='parsing',error=NULL,updated=? WHERE id=? AND (status IN ('waiting','failed') OR (status IN ('parsing','scoring') AND updated<?))").bind(token,now,row.evaluation_id,now-240000).run();
 if(!claim.meta.changes)return;
 try{
  let text=row.resume_text;
  if(!text){const object=await runtime().BUCKET.get(row.file_key);if(!object)throw new AppError('原始文件暂时无法读取，请重试');text=await parseDocument(await object.arrayBuffer(),row.filename);await d.prepare('UPDATE candidates SET resume_text=? WHERE id=?').bind(text,id).run();}
  const raw:any=await d.prepare('SELECT data FROM scorecards WHERE id=?').bind(row.scorecard_id).first();const card=cardSchema.parse(JSON.parse(raw.data));
  await d.prepare("UPDATE evaluations SET status='scoring',updated=? WHERE id=? AND lease=?").bind(Date.now(),row.evaluation_id,token).run();
  const result=await callAI('resume',id,owner,resumePrompt(card),{job_profile:JSON.parse(row.job_profile),resume:text},x=>validateEvaluation(x,card,text));
  await d.batch([d.prepare('UPDATE candidates SET name=?,profile=? WHERE id=?').bind(result.candidate_profile.name||row.name,JSON.stringify(result.candidate_profile),id),d.prepare("UPDATE evaluations SET status='completed',score=?,result=?,error=NULL,lease=NULL,updated=? WHERE id=? AND lease=?").bind(result.total_score,JSON.stringify(result),Date.now(),row.evaluation_id,token)]);
 }catch(error){await d.prepare("UPDATE evaluations SET status='failed',error=?,lease=NULL,updated=? WHERE id=? AND lease=?").bind(error instanceof AppError?error.message:'分析未完成，请重试。原始简历已保留。',Date.now(),row.evaluation_id,token).run();}
}
