import { env } from 'cloudflare:workers';
export type Runtime = {
  DB: D1Database;
  BUCKET: R2Bucket;
  DEEPSEEK_API_KEY?: string;
  DEEPSEEK_JOB_MODEL?: string;
  DEEPSEEK_RESUME_MODEL?: string;
  API_KEY_ENCRYPTION_SECRET?: string;
  DEFAULT_AI_OWNER_EMAIL?: string;
};
export function runtime() { return env as unknown as Runtime; }
export function db() {
  const d = runtime().DB;
  if (!d) throw new Error('数据库暂时不可用');
  return d;
}
export const json = (data: unknown, status = 200) => Response.json(data, {
  status, headers: { 'Cache-Control': 'no-store' },
});
export class AppError extends Error {
  constructor(message: string, public status = 400) { super(message); }
}
