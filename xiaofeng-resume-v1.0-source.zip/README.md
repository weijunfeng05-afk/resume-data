# 小锋牌简历 V1.0

面向Recruiter的证据驱动简历初筛工作台。先确认岗位标准，再自动分析简历并按查看优先级排序。

开发入口：docs/01-v1-tasks.md；数据库与接口：docs/02-database-api.md；模型合同：docs/03-ai-contract.md；交互：docs/04-interactions.md。

## 运行
Node.js 22+，npm ci，npm run dev。平台后端使用Workers + D1 + R2；部署配置位于.openai/hosting.json。正式环境使用平台私有访问策略及用户身份头，所有岗位和文件均按owner鉴权。开发预览通过“登录工作空间”入口进入本地模拟身份。

每位登录用户可在「API 设置」中填写自己的 DeepSeek API Key，并选择岗位理解与简历筛选模型。后端会先验证模型连接，再使用 AES-GCM 加密保存；完整密钥不会回显、写入前端或提交到 Git。生产环境必须配置 32 字节 Base64 的 `API_KEY_ENCRYPTION_SECRET`。

`DEEPSEEK_API_KEY`、`DEFAULT_AI_OWNER_EMAIL` 与模型环境变量只用于把旧版全局配置安全迁移到指定原始账户；新用户必须从页面独立配置。未配置时 AI 操作明确失败，原文件保留，不生成模拟评分。

构建：npm run build。类型检查：npx tsc --noEmit。业务合同测试：node --test tests/scoring.test.mjs。JSON Schema导出：node scripts/export-contracts.mjs。数据库迁移：npm run db:generate，生产由Sites逐个应用drizzle迁移。

本地数据库：构建后运行 node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_sparkling_champions.sql ，只执行一次。

排名验收：node scripts/ranking-metrics.mjs dataset.json [人工耗时秒] [辅助后耗时秒]。输入至少10行 {id,human_rank,ai_score}；推荐20份真实匿名简历。

当前限制、真实模型和排名质量验收的待办见docs/01-v1-tasks.md。本轮尚不能以界面完成代替真实Top5质量验收。
