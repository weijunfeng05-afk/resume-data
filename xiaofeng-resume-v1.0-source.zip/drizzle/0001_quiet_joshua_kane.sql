CREATE TABLE `api_settings` (
	`owner` text PRIMARY KEY NOT NULL,
	`encrypted_key` text,
	`key_suffix` text,
	`job_model` text DEFAULT 'deepseek-v4-pro' NOT NULL,
	`resume_model` text DEFAULT 'deepseek-v4-flash' NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`updated` integer NOT NULL
);
