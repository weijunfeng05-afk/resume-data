CREATE TABLE `ai_calls` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`subject` text NOT NULL,
	`task` text NOT NULL,
	`model` text NOT NULL,
	`attempt` integer NOT NULL,
	`latency` integer NOT NULL,
	`input_tokens` integer,
	`output_tokens` integer,
	`estimated_cost` real,
	`json_valid` integer NOT NULL,
	`success` integer NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `calls_owner_created` ON `ai_calls` (`owner`,`created`);--> statement-breakpoint
CREATE TABLE `candidates` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`name` text NOT NULL,
	`filename` text NOT NULL,
	`file_key` text NOT NULL,
	`mime` text NOT NULL,
	`resume_text` text,
	`profile` text,
	`created` integer NOT NULL,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `candidates_job_created` ON `candidates` (`job_id`,`created`);--> statement-breakpoint
CREATE TABLE `evaluations` (
	`id` text PRIMARY KEY NOT NULL,
	`candidate_id` text NOT NULL,
	`scorecard_id` text NOT NULL,
	`version` integer NOT NULL,
	`status` text NOT NULL,
	`score` integer,
	`result` text,
	`error` text,
	`lease` text,
	`updated` integer NOT NULL,
	`created` integer NOT NULL,
	FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`scorecard_id`) REFERENCES `scorecards`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `evaluation_candidate` ON `evaluations` (`candidate_id`);--> statement-breakpoint
CREATE INDEX `evaluation_status` ON `evaluations` (`status`);--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`department` text DEFAULT '' NOT NULL,
	`location` text DEFAULT '' NOT NULL,
	`level` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`jd` text NOT NULL,
	`profile` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`confirmed` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `jobs_owner_updated` ON `jobs` (`owner`,`updated`);--> statement-breakpoint
CREATE TABLE `scorecards` (
	`id` text PRIMARY KEY NOT NULL,
	`job_id` text NOT NULL,
	`version` integer NOT NULL,
	`data` text NOT NULL,
	`created` integer NOT NULL,
	FOREIGN KEY (`job_id`) REFERENCES `jobs`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `scorecards_job_version` ON `scorecards` (`job_id`,`version`);